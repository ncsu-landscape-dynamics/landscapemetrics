# library(raster)
#
# landscape_brick <- brick(landscape_stack)
#
